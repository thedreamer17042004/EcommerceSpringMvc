create database BtlSpring2
go
use BtlSpring2
go
CREATE TABLE Accounts(
	AccountId VARCHAR(36) PRIMARY KEY,
	UserName VARCHAR(64) NOT NULL,
	Password VARCHAR(256),
	FullName NVARCHAR(100),
	Picture VARCHAR(512),
	Email VARCHAR(64) UNIQUE NOT NULL,
    Gender bit,
    birthday date,
	Address NVARCHAR(256),
	Phone VARCHAR(64),
	Active BIT,
	deleted_at bit 
)
GO
create table Roles(
    RoleId int PRIMARY key identity,
    RoleName varchar(255) not null,
	Active bit,
	deleted_at bit 
)
GO

create table Account_Roles(
    Id int PRIMARY key identity,
    AccountId varchar(36) FOREIGN key references Accounts(AccountId) ON DELETE CASCADE,
    RoleId int references Roles(RoleId) ON DELETE CASCADE
)
GO

go

-- permission yes or no i don't know
create table Categories(
	Id int PRIMARY key identity,
    Category_name nvarchar(255) not null,
	Slug varchar(255) DEFAULT null,
	Picture varchar(255) null,
	Active bit,
	Parentid INT NULL,
	deleted_at bit,
)

GO
	
create table Brands(
    BrandId int PRIMARY key identity,
    BrandName varchar(255) not null,
	Active bit,
	Slug varchar(255) DEFAULT null,
	deleted_at bit 
)

GO

create table Products(
	Id varchar(255) PRIMARY key,
	Price float(53) not null,
    ProductName  nvarchar(255) not null,
	Description nvarchar(255) null,
	Slug varchar(255) DEFAULT null,
	Image varchar(255) DEFAULT null,
	Category_id  int FOREIGN KEY REFERENCES Categories(Id),
	Sale_price float(53) DEFAULT 0.00,
	Publish bit not null DEFAULT 1,
	Brand_id int  FOREIGN KEY REFERENCES Brands(BrandId),
	Album text DEFAULT null,
	deleted_at bit 
)
GO
create table PostCategories(
	Id int PRIMARY key identity,
    Post_category_name  nvarchar(255) not null,
	Description nvarchar(255) null,
	Slug varchar(255) DEFAULT null,
	Image varchar(255) DEFAULT null,
	Publish bit not null DEFAULT 1,
	Parentid INT NULL,
	deleted_at bit ,
    

)

GO
create table Posts(
	Id varchar(255) PRIMARY key,
    PostName  nvarchar(255) not null,
	Description text null,
	Content Text not null,
	Slug varchar(255) DEFAULT null,
	Image varchar(255) DEFAULT null,
	Publish bit not null DEFAULT 1,
	Post_category_id int  FOREIGN KEY REFERENCES Brands(BrandId),
	Album text DEFAULT null,
	User_id varchar(36) FOREIGN key references  Accounts(AccountId),
	deleted_at bit 
)

GO

CREATE TABLE OrderProducts(
	OrderId VARCHAR(16) PRIMARY KEY,
	OrderDate DATETIME,
	AccountId VARCHAR(36),
	ReceiveAddress NVARCHAR(512),
	ReceivePhone VARCHAR(50),
	ReceiveDate DATETIME,
	Note NVARCHAR(512),
	Status BIT,
	Createdate DATE
)
GO

CREATE TABLE OrderDetail(
	OrderDetailId INT Identity(1,1) PRIMARY KEY,
	OrderId VARCHAR(16),
	ProductId VARCHAR(10),
	Quantity INT,
	Price FLOAT
)

GO

ALTER TABLE OrderDetail ADD FOREIGN KEY (OrderId) REFERENCES OrderProducts(OrderId) ON DELETE CASCADE;
GO
ALTER TABLE OrderDetail
ALTER COLUMN  ProductId VARCHAR(255);
GO
ALTER TABLE OrderDetail ADD FOREIGN KEY (ProductId) REFERENCES Products(Id);
GO


ALTER TABLE Posts
ADD CONSTRAINT fk_PostCategory FOREIGN KEY (Post_category_id) REFERENCES PostCategories(Id);

go
-- 12345
INSERT INTO Accounts (AccountId, UserName, Password, FullName, Picture, Email)
VALUES 
('1', 'Nam', '$2a$12$jukAsGNTZPD0GRKkse1Gz.sQYQc8awziQFlD.R5fhckJT4ce91q3q', 'ADMIN Nam', '', 'admin@gmail.com'),
('2', 'Khôi', '$2a$12$60gUzsoFEIxVjx1PWnq46urTSjHBCUL6kdPvFRTVyNLWwHp7tCuUa', 'User khôi', '', 'khoi@gmail.com'),
('3', 'Việt', '$2a$12$HWieS/bs6vwthNUhhdl0/uw8usZp2Tt1C58oQXt.hNvbE//66DsCG', 'Manager Việt', '', 'viet@gmail.com');

go
insert into Roles(RoleName) values ('ADMIN'),
('USER'),
('MANAGER')

go
insert into Account_Roles( AccountId, RoleId) 
values( 1, 1),
( 2, 2),
(3, 3)

